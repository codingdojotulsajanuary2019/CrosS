using System;

namespace CSharpProject.Models
{
    public class MyModel
    {
       
    }
}