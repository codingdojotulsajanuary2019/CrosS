from sl_list import SL_list
from sl_node import Node


my_list = SL_list()
my_list.add_to_back(3).add_to_back(9).insert_at(1, 6).print_values()