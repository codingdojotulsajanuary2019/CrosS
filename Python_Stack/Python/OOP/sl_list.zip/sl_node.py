class Node:
    def __init__(self, val):
        self.value = val
        self.next = None
        